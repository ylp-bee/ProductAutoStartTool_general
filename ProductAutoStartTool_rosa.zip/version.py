# -*- coding: UTF-8 -*-
program_version_no = 'General_V1.6.0.0(build11)'
modify_content=r'General_V1.6.0.0(build11)新增了om模块的启动\关闭\复制OM功能、启动删除log功能，config新增内容并更改之前的bsmonitorpath为csmonitorpath' \
               r'General_V1.5.0.0(build10)支持老的通用框架的部署' \
               r'General_V1.4.0.0(build9)增减单独启动和关闭webmonitor的操作' \
               r'General_V1.4.0.0(build8)ftp_port 写成了fts_port，修正' \
               r'General_V1.4.0.0(build7)调整优化function_write_to_xml的代码' \
               r'General_V1.3.0.0(build6)更改agv_infoxml的删除方法' \
               r'1.3.0.0(build5)写入dispatch_info的代码更新，ID等不为浮点数为整数' \
               r'1.3.0.0(build4)写入AGV_info代码更新,打包文档命名规范修改' \
               r'1.2.0.0(build3)写入engine信息为int' \
               r'1.1.0.0(build)_2020/9/4日代码修正,从excel读0不会修改xml' \
               r'1.0.1.0-2020/8/28增加sd的配置以及启动。' \
               r'1.0.0.2-2020/8/27在写入ini配置文件中，若是ini文件有注释，使用open r+的方法就不会覆 盖修改，直接用w+方式，去掉注释，使得文件的sections不会重复。'